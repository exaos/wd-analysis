
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "string.h"

typedef struct a {
  int n;
  struct nest_b {
    int a;
    int b;
  } nb;
  double cc;
} a_t;

// cast data
uint8_t  iorig8 [10] = { 2, 3, 5, 7, 9, 11, 99, 32, 41, 127 };
uint16_t iorig16[10] = { 3, 4, 6, 8,10, 12,300, 33, 42, 128 };
uint32_t iorig32[10] = {13,14,16,18,20,112,400,533,542,1339355};

// test cast
void iarr_cast(const void *data, int nlen, int ndigi)
{
  int *iarr;
  int  idx;

  switch(ndigi) {
  case 1:
    iarr = (uint8_t *) data;
    break;
  case 2:
    iarr = (uint16_t *) data;
    break;
  case 4:
  default:
    iarr = (uint32_t *) data;
    break;
  }

  printf("cast data:\n");
  for(idx=0; idx<nlen; idx++) {
    printf("  %d", iarr[idx]);
  }
  printf("\n");
}

void iarr_cast2(const void *data, int nlen, int ndigi)
{
  int  idx;

  printf("cast data 2:\n");
  for(idx=0; idx<nlen; idx++) {
    switch(ndigi) {
    case 1:
      printf("  %d", *((uint8_t *)data + idx));
      break;
    case 2:
      printf("  %d", *((uint16_t *)data + idx));
      break;
    case 4:
    default:
      printf("  %d", *((uint32_t *)data + idx));
      break;
    }
  }
  printf("\n");
}

typedef struct WaveForm {
  int   ndigi;  // choice: 1,2,4 -- 8,16,32-bit; typical: 2
  int   nlen;   // data length
  void *data;   // the pointer to data array
} WaveForm_t;


uint32_t* cast_data(const WaveForm_t *fwave)
{
  int       idx=0;
  uint32_t *acast = calloc(fwave->nlen, sizeof(uint32_t));
  for(; idx<fwave->nlen; idx++) {
    switch( fwave->ndigi ) {
    case 1:
      *(acast+idx) = *((uint8_t *) fwave->data + idx);
      break;
    case 2:
      *(acast+idx) = *((uint16_t *) fwave->data + idx);
      break;
    case 4:
    default:
      *(acast+idx) = *((uint32_t *) fwave->data + idx);
    break;
    }
  }
  return acast;
}

//====================

void main()
{
  a_t a1;
  // intptr_t  iarr;
  int      *iarr;
  double   *darr;
  uint32_t *iarr32;

  // Waveform
  WaveForm_t t_wave1, t_wave2, t_wave3;
  uint8_t  w1[6] = { 112, 111, 110, 33, 112, 111 };
  uint16_t w2[6] = { 1112, 1111, 1110, 133, 1112, 1111 };
  uint32_t w3[6] = { 11112, 11111, 11110, 133, 11112, 11111 };
  t_wave1.ndigi = 1;
  t_wave1.nlen = 6;
  t_wave1.data = w1;
  t_wave2.ndigi = 2;
  t_wave2.nlen = 6;
  t_wave2.data = w2;
  t_wave3.ndigi = 4;
  t_wave3.nlen = 6;
  t_wave3.data = w3;

  // ....  
  int idx;
  
  // test truct in struct
  a1.n = 100;
  a1.nb.a = 10;
  a1.nb.b = 3;
  printf("a1.nb.a: %d; a1.nb.b: %d\n", a1.nb.a, a1.nb.b);
  a1.cc = 3.1415;
  printf("a1.cc: %f\n", a1.cc);

  // calloc
  // iarr = (int *)calloc(10, sizeof(uint16_t));
  iarr = (uint16_t *)calloc(10, sizeof(uint16_t));
  for(idx=0;idx<10;idx++) {
    printf(" %d", iarr[idx]);
  }
  printf("\n");
  for(idx=10;idx<10;idx++) {
    iarr[idx] = 0x10 * 1<<idx;
    printf(" %d", iarr[idx]);
  }
  printf("\n");

  // test int pointer
  iarr = (uint16_t *) malloc( 10 * sizeof(uint16_t));
  for(idx=0;idx<10;idx++) {
    iarr[idx] = 1 << idx;
    printf("  %d", iarr[idx]);
  }
  printf("\n");
  // free((void *)iarr);

  // iarr = (uint8_t *) malloc( 10 * sizeof(uint8_t));
  printf("uint8_t:\n");
  // memset((void *)iarr, 0, 10*sizeof(uint8_t));
  for(idx=0;idx<10;idx++) {
    iarr[idx]=0;
    printf("  %d", iarr[idx]);
    // printf("  %d", *(iarr+idx));
  }
  printf("\n");
  for(idx=0;idx<10;idx++) {
    iarr[idx] = 10-idx;
    printf("  %d", iarr[idx]);
  }
  printf("\nNew memeory:\n");
  // free((void *)iarr);
  
  // test double pointer
  darr = (double*) malloc(10*sizeof(double));
  printf("double array:");
  for(idx=0;idx<10;idx++) {
    darr[idx] = 3.1415 * idx / 10.;
    printf("  %10.5f", darr[idx]);
  }
  printf("\n");
  // free((void *)darr);

  // ====================
  iarr_cast( iorig8,  10, 1 );
  iarr_cast( iorig16, 10, 2 );
  iarr_cast( iorig32, 10, 4 );
  iarr_cast2( iorig8,  10, 1 );
  iarr_cast2( iorig16, 10, 2 );
  iarr_cast2( iorig32, 10, 4 );


  // cast wave
  printf("Wave data cast:\n");
  iarr32 = cast_data( &t_wave1 );
  for(idx=0;idx<t_wave1.nlen;idx++) {
    printf(" %5d", iarr32[idx]);
  }
  printf("\n");
  iarr32 = cast_data( &t_wave2 );
  for(idx=0;idx<t_wave2.nlen;idx++) {
    printf(" %5d", iarr32[idx]);
  }
  printf("\n");
  iarr32 = cast_data( &t_wave3 );
  for(idx=0;idx<t_wave3.nlen;idx++) {
    printf(" %5d", iarr32[idx]);
  }
  printf("\n");
}

