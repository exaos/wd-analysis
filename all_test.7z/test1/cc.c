
/* struct closure { */
/*   void (*call)(struct closure *); */
/*   int x; */
/* }; */

/* struct closure * foo(int x) */
/* { */
/*   struct closure * closure = (struct closure *) malloc(sizeof(struct consure *)); */
/*   closure->x = x; */
/*   printf("x is %d\n", closure->x); */
/*   // closure->call = ... */
/*   return closure; */
/* } */


struct env {
  int x;
};

struct closure {
  void (* call)(struct env *);
  struct env *env;
};

void block( struct env *env) {
  env->x += 1;
  printf("block: x is %d\n", env->x);
}

struct closure *foo1(int x)
{
  struct env *env = (struct env *) malloc( sizeof(struct env) );
  env->x = x;

  printf("x is %d\n", env->x);

  struct closure *closure = (struct closure *) malloc(sizeof(struct closure *));
  closure->env = env;
  closure->call = block;

  return closure;
}

struct closure foo2(int x)
{
  struct env *env = (struct env *) malloc( sizeof(struct env) );
  env->x = x;

  printf("x is %d\n", env->x);

  struct closure closure;
  closure.env = env;
  closure.call = block;

  return closure;
}

int main()
{
  struct closure *c1 = foo1(5);
  struct closure c2 = foo2(88);

  c1->call(c1->env);
  c1->call(c1->env);

  c2.call(c2.env);
  c2.call(c2.env);
  
  return 0;
}

